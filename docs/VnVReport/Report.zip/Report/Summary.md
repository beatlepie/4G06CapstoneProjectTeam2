﻿# Summary
|||
|:---|:---|
| Generated on: | 3/6/2024 - 10:58:29 PM |
| Parser: | MultiReportParser (2x OpenCoverParser) |
| Assemblies: | 2 |
| Classes: | 41 |
| Files: | 41 |
| Covered lines: | 313 |
| Uncovered lines: | 2126 |
| Coverable lines: | 2439 |
| Total lines: | 4332 |
| Line coverage: | 12.8% (313 of 2439) |
| Covered branches: | 0 |
| Total branches: | 0 |
| Covered methods: | 36 |
| Total methods: | 277 |
| Method coverage: | 12.9% (36 of 277) |

|**Name**|**Covered**|**Uncovered**|**Coverable**|**Total**|**Line coverage**|**Covered**|**Total**|**Branch coverage**|**Covered**|**Total**|**Method coverage**|
|:---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|
|**Assembly-CSharp**|**132**|**1865**|**1997**|**3593**|**6.6%**|**0**|**0**|****|**18**|**228**|**7.8%**|
|ARCameraInfo|0|52|52|76|0%|0|0||0|6|0%|
|AuthManager|0|149|149|261|0%|0|0||0|9|0%|
|BuildingClickHandler|0|3|3|15|0%|0|0||0|1|0%|
|BuildingLocation|0|1|1|12|0%|0|0||0|1|0%|
|ChatHelper|0|3|3|10|0%|0|0||0|1|0%|
|ClickManager|2|61|63|108|3.1%|0|0||1|11|9%|
|Event|23|0|23|39|100%|0|0||3|3|100%|
|EventCarousel|0|63|63|93|0%|0|0||0|5|0%|
|EventCarouselCell|0|16|16|39|0%|0|0||0|3|0%|
|EventCarouselData|0|9|9|15|0%|0|0||0|4|0%|
|EventDetailViewManager|0|85|85|143|0%|0|0||0|9|0%|
|EventManager|0|199|199|298|0%|0|0||0|16|0%|
|FirebaseInit|0|11|11|24|0%|0|0||0|2|0%|
|FriendManager|0|217|217|322|0%|0|0||0|19|0%|
|GeoCoordinatePortable.GeoCoordinate|0|100|100|341|0%|0|0||0|27|0%|
|InputFieldHandler|0|39|39|78|0%|0|0||0|6|0%|
|Lecture|17|0|17|27|100%|0|0||3|3|100%|
|LectureCarousel|0|53|53|83|0%|0|0||0|5|0%|
|LectureCarouselCell|0|16|16|39|0%|0|0||0|3|0%|
|LectureCarouselData|0|9|9|15|0%|0|0||0|4|0%|
|LectureDetailViewManager|0|77|77|126|0%|0|0||0|9|0%|
|LectureManager|0|184|184|282|0%|0|0||0|16|0%|
|MenuManager|0|33|33|56|0%|0|0||0|8|0%|
|Message|0|3|3|13|0%|0|0||0|3|0%|
|Pagination[T]|70|3|73|109|95.8%|0|0||9|9|100%|
|ScrollViewItem|0|7|7|27|0%|0|0||0|2|0%|
|SettingsManager|0|246|246|479|0%|0|0||0|15|0%|
|SignalRConnector|0|13|13|51|0%|0|0||0|2|0%|
|SignalRService|0|18|18|35|0%|0|0||0|6|0%|
|SpawnOnMap|1|30|31|60|3.2%|0|0||1|3|33.3%|
|TargetBuilding|0|10|10|24|0%|0|0||0|3|0%|
|TextBox|0|21|21|40|0%|0|0||0|2|0%|
|ToggleManager|0|27|27|49|0%|0|0||0|3|0%|
|UIManager|0|19|19|37|0%|0|0||0|3|0%|
|User|19|0|19|38|100%|0|0||1|1|100%|
|Utilities|0|88|88|129|0%|0|0||0|5|0%|
|**Assembly-CSharp-Editor**|**181**|**261**|**442**|**739**|**40.9%**|**0**|**0**|****|**18**|**49**|**36.7%**|
|AddVuforiaEnginePackage|0|261|261|478|0%|0|0||0|31|0%|
|EventTest|27|0|27|42|100%|0|0||3|3|100%|
|LectureTest|21|0|21|36|100%|0|0||3|3|100%|
|PaginationTest|89|0|89|121|100%|0|0||8|8|100%|
|UserTest|44|0|44|62|100%|0|0||4|4|100%|
